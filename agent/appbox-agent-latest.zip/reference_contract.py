"""Portable reference archive primitives shared by the agent and Control Plane."""
import gzip
import hashlib
import os
import re
import shutil
import sqlite3
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

PLEX_ROOT = 'Library/Application Support/Plex Media Server'
IDENTITY_ATTRIBUTES = (
    'MachineIdentifier', 'ProcessedMachineIdentifier', 'AnonymousMachineIdentifier',
    'PlexOnlineToken', 'PlexOnlineUsername', 'PlexOnlineMail', 'PlexOnlineHome',
    'CertificateUUID', 'PubSubServer', 'PubSubServerRegion',
    'PlexClaim', 'PLEX_CLAIM', 'ClaimToken', 'PlexOnlineAuthToken',
    'LastAutomaticMappedPort',
)
HOST_ATTRIBUTES = {'FriendlyName', 'ManualPortMappingMode', 'ManualPortMappingPort',
                   'LastAutomaticMappedPort', 'customConnections'}


def identity_attribute(name):
    lower = name.lower()
    return lower in {key.lower() for key in IDENTITY_ATTRIBUTES} or any(
        word in lower for word in ('token', 'password', 'secret', 'claim')
    )


def sanitize_preferences(path):
    tree = ET.parse(path)
    root = tree.getroot()
    if root.tag != 'Preferences':
        raise RuntimeError('Preferences.xml invalide.')
    removed = []
    for key in list(root.attrib):
        if identity_attribute(key) or key.lower() in {name.lower() for name in HOST_ATTRIBUTES}:
            root.attrib.pop(key)
            removed.append(key)
    tree.write(path, encoding='utf-8', xml_declaration=True)
    return removed


def plex_runtime_preferences(client_id, port):
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{2,20}', client_id) or '--' in client_id or client_id.endswith('-'):
        raise RuntimeError('Identifiant Plex invalide.')
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise RuntimeError('Port Plex alloué invalide.')
    return {'FriendlyName': client_id.upper(), 'ManualPortMappingMode': '1',
            'ManualPortMappingPort': str(port)}


def apply_plex_runtime_preferences(config_dir, client_id, port):
    """Initialize only a new instance; never call on claim/recreate of an existing one."""
    values = plex_runtime_preferences(client_id, port)
    path = Path(config_dir) / PLEX_ROOT / 'Preferences.xml'
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise RuntimeError('Preferences.xml ne doit pas être un lien.')
    tree = ET.parse(path) if path.exists() else ET.ElementTree(ET.Element('Preferences'))
    root = tree.getroot()
    if root.tag != 'Preferences':
        raise RuntimeError('Preferences.xml invalide.')
    for key in list(root.attrib):
        if identity_attribute(key) or key.lower() in {name.lower() for name in HOST_ATTRIBUTES}:
            root.attrib.pop(key)
    root.attrib.update(values)
    temporary = path.with_name('.Preferences.xml.appbox-tmp')
    try:
        with temporary.open('xb') as stream:
            tree.write(stream, encoding='utf-8', xml_declaration=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _progress(callback, stage, completed=0, total=0, detail=''):
    if callback:
        callback(stage, completed, total, detail)


def sha256_file(path, progress_callback=None):
    digest = hashlib.sha256()
    path=Path(path); total=path.stat().st_size; completed=0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            completed+=len(block); _progress(progress_callback,'checksum_reference',completed,total,'Calcul SHA-256 du cache de référence.')
    return digest.hexdigest()


def redact_result(value):
    """Boundary sanitization before persisting remote results or event messages."""
    if isinstance(value, dict):
        return {str(key): '[REDACTED]' if re.search(r'token|password|secret|authorization|claim_code', str(key), re.I)
                else redact_result(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact_result(item) for item in value]
    if isinstance(value, str):
        value = re.sub(r'(?i)\bclaim-[A-Za-z0-9_-]{8,}\b', 'claim-[REDACTED]', value)
        value = re.sub(r'(?i)((?:X-Plex-Token|PlexOnlineToken|PLEX_CLAIM|token|password|secret|api[_-]?key)["\x27]?\s*[:=]\s*)[^\s,;&<>]+', r'\1[REDACTED]', value)
        value = re.sub(r'(?i)(authorization\s*:\s*)\S+(?:\s+\S+)?', r'\1[REDACTED]', value)
        value = re.sub(r'(?i)(https?://)[^/@\s:]+:[^/@\s]+@', r'\1[REDACTED]@', value)
    return value


def archive_member_path(member):
    name = member.name
    path = PurePosixPath(name)
    if (not name or '\\' in name or ':' in name or path.is_absolute()
            or '..' in path.parts or not path.parts
            or not (member.isfile() or member.isdir())):
        raise RuntimeError('Archive invalide : chemin ou type de fichier interdit.')
    return path


def validate_archive(path, plex=False, progress_callback=None):
    # Consume gzip to EOF as tar readers may otherwise ignore a truncated trailer.
    expanded = 0
    with gzip.open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            expanded += len(block)
            _progress(progress_callback,'archive_validation',expanded,0,'Lecture complète du flux gzip.')
            if expanded > 501 * 1024**3:
                raise RuntimeError('Archive de référence trop volumineuse.')
    names = set()
    files = set()
    total = 0
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            relative = archive_member_path(member)
            name = relative.as_posix()
            if name in names or any(parent.as_posix() in files for parent in relative.parents):
                raise RuntimeError('Archive invalide : chemins dupliqués ou conflictuels.')
            names.add(name)
            if member.isfile():
                files.add(name)
                total += member.size
            if len(names) > 2000000 or total > 500 * 1024**3:
                raise RuntimeError('Archive de référence trop volumineuse.')
            if plex:
                root = PurePosixPath(PLEX_ROOT)
                if relative in root.parents or relative == root:
                    if not member.isdir():
                        raise RuntimeError('Archive Plex : racine invalide.')
                    continue
                try:
                    local = relative.relative_to(root)
                except ValueError:
                    raise RuntimeError('Archive Plex : chemin hors contrat.') from None
                allowed = {'Metadata', 'Media', 'Plug-in Support', 'Plug-ins', 'Scanners', 'Profiles', 'Resources', 'Preferences.xml'}
                if local.parts[0] not in allowed:
                    raise RuntimeError('Archive Plex : chemin hors contrat.')
                lower = [part.lower() for part in local.parts]
                if (set(lower) & {'cache','logs','crash reports','codecs','diagnostics','sessions','session','transcode','transcodes','tmp','temp'}
                        or lower[-1].endswith(('.pid','-wal','-shm','-journal','.tmp','.temp','.log','.dmp','.partial','.part','.swp','.lock','~'))
                        or lower[-1].startswith(('.transcode','transcode-','transcode_'))
                        or lower[-1] in {'.env', 'credentials.json'}
                        or lower[-1].endswith(('.pem', '.key', '.p12', '.pfx'))):
                    raise RuntimeError('Archive Plex : contenu transitoire ou secret interdit.')
                if local.parts[0] == 'Plug-in Support' and member.isfile():
                    if (len(local.parts) != 3 or local.parts[1] != 'Databases'
                            or not local.name.endswith('.db') or 'backup' in local.name.lower()
                            or local.name[:-3].lower().endswith(('-copy', '_copy'))
                            or re.search(r'20\d{2}[-_.]\d{2}[-_.]\d{2}', local.name)):
                        raise RuntimeError('Archive Plex : base hors contrat.')
                    # Validate database contents, not just a .db filename in a tar.
                    with tempfile.TemporaryDirectory(prefix='archive-sqlite-', dir=Path(path).parent) as directory:
                        database = Path(directory) / 'validation.db'
                        with archive.extractfile(member) as source, database.open('wb') as output:
                            copied = 0
                            while True:
                                block = source.read(1024 * 1024)
                                if not block:
                                    break
                                output.write(block)
                                copied += len(block)
                                _progress(progress_callback, 'archive_validation', copied, member.size,
                                          f'Prévalidation SQLite {local.name}.')
                        connection = sqlite3.connect(database.resolve().as_uri() + '?mode=ro', uri=True)
                        try:
                            connection.set_progress_handler(
                                lambda: (_progress(
                                    progress_callback, 'sqlite_validation', 0, 0,
                                    f'Quick check SQLite {local.name} en cours.'
                                ), 0)[1],
                                10000,
                            )
                            try:
                                check = connection.execute('PRAGMA quick_check').fetchone()
                                if not check or check[0] != 'ok':
                                    raise RuntimeError('Archive Plex : base SQLite incohérente.')
                            except sqlite3.OperationalError as exc:
                                if 'unknown tokenizer' not in str(exc).lower():
                                    raise
                                connection.execute('SELECT count(*) FROM sqlite_master').fetchone()
                        finally:
                            connection.close()
                if name == PLEX_ROOT + '/Preferences.xml':
                    if not member.isfile() or member.size > 1024 * 1024:
                        raise RuntimeError('Preferences.xml invalide.')
                    prefs = ET.fromstring(archive.extractfile(member).read())
                    if prefs.tag != 'Preferences' or any(identity_attribute(key) for key in prefs.attrib):
                        raise RuntimeError('Archive Plex : identité source présente.')
            if len(names) % 256 == 0:
                _progress(progress_callback,'archive_validation',len(names),0,'Validation des membres de l’archive.')
    if not files:
        raise RuntimeError('Archive vide.')
    if plex:
        required = [PLEX_ROOT + '/' + value for value in ('Metadata', 'Media')]
        if any(not any(n == prefix or n.startswith(prefix + '/') for n in names) for prefix in required):
            raise RuntimeError('Archive Plex : Metadata/Media absents.')
        if not {PLEX_ROOT+'/Preferences.xml', PLEX_ROOT+'/Plug-in Support/Databases/com.plexapp.plugins.library.db'} <= files:
            raise RuntimeError('Archive Plex : préférences ou base canonique absentes.')
    return {'file_count': len(files), 'uncompressed_size_bytes': total}


def extract_archive(path, destination, progress_callback=None):
    report=validate_archive(path,progress_callback=progress_callback)
    destination = Path(destination).resolve()
    # Preflight every path before writing even into staging.
    with tarfile.open(path, 'r:gz') as archive:
        completed=0; total=max(1,int(report.get('uncompressed_size_bytes') or 1))
        for member in archive:
            target = destination.joinpath(*archive_member_path(member).parts).resolve()
            if target != destination and destination not in target.parents:
                raise RuntimeError('Archive invalide : chemin hors staging.')
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive:
            target = destination.joinpath(*archive_member_path(member).parts)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.extractfile(member) as source, target.open('xb') as output:
                    while True:
                        block=source.read(1024*1024)
                        if not block: break
                        output.write(block); completed+=len(block)
                        _progress(progress_callback,'extraction',completed,total,'Extraction atomique dans le staging.')
                target.chmod((member.mode & 0o755) | 0o600)
